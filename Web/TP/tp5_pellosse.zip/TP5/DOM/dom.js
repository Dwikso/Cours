window.addEventListener("DOMContentLoaded", (event) => {
  const title = document.title;
  alert(`Titre de la page : ${title}`);
});
